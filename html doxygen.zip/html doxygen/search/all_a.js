var searchData=
[
  ['platform_5fid_0',['PLATFORM_ID',['../_c_make_c_compiler_id_8c.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID():&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID():&#160;CMakeCXXCompilerId.cpp']]],
  ['printdataonconsole_1',['printDataOnConsole',['../grades__section1_8cpp.html#ad2d2aa6511f877b905b0f56c7a23f3d2',1,'printDataOnConsole(Student &amp;student):&#160;grades_section1.cpp'],['../grades__section1_8h.html#a899fba67a0a6a58ba07ebff38c48390b',1,'printDataOnConsole(Student &amp;):&#160;grades_section1.cpp']]],
  ['printhorizontaldivider_2',['printHorizontalDivider',['../grades__section1_8cpp.html#a24b443af08f6c10ffb778616ed5e02af',1,'printHorizontalDivider():&#160;grades_section1.cpp'],['../grades__section1_8h.html#a24b443af08f6c10ffb778616ed5e02af',1,'printHorizontalDivider():&#160;grades_section1.cpp']]],
  ['printtableheadertoconsole_3',['printTableHeaderToConsole',['../grades__section1_8cpp.html#a4d578336e46c2c854ea6f01fb3546160',1,'printTableHeaderToConsole():&#160;grades_section1.cpp'],['../grades__section1_8h.html#a4d578336e46c2c854ea6f01fb3546160',1,'printTableHeaderToConsole():&#160;grades_section1.cpp']]]
];

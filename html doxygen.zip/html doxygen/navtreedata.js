/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "CS-700 Assignment 1", "index.html", [
    [ "CS-700 Assignment 1", "md__r_e_a_d_m_e.html", [
      [ "Getting Started", "md__r_e_a_d_m_e.html#autotoc_md1", [
        [ "1. Main file containing both modules.", "md__r_e_a_d_m_e.html#autotoc_md3", null ],
        [ "Contents -", "md__r_e_a_d_m_e.html#autotoc_md4", null ],
        [ "Usage -", "md__r_e_a_d_m_e.html#autotoc_md5", [
          [ "This assignment contains a program to read student names and scores from a file to calculate average score and grades. The program contains the following:", "md__r_e_a_d_m_e.html#autotoc_md2", null ],
          [ "Running the main() function will run both the modules.", "md__r_e_a_d_m_e.html#autotoc_md6", null ]
        ] ],
        [ "2. Module 1 - Calculating Average score and Grades of Students.", "md__r_e_a_d_m_e.html#autotoc_md7", [
          [ "Contents -", "md__r_e_a_d_m_e.html#autotoc_md8", null ]
        ] ],
        [ "Usage -", "md__r_e_a_d_m_e.html#autotoc_md9", [
          [ "Running this program will print name and calculated score average and grade of each student.", "md__r_e_a_d_m_e.html#autotoc_md10", null ]
        ] ],
        [ "Output -", "md__r_e_a_d_m_e.html#autotoc_md11", null ],
        [ "3. Module 2 - Calculating Average subject score and grades for every subject of every student.", "md__r_e_a_d_m_e.html#autotoc_md12", [
          [ "Contents -", "md__r_e_a_d_m_e.html#autotoc_md13", null ]
        ] ],
        [ "Usage -", "md__r_e_a_d_m_e.html#autotoc_md14", [
          [ "Running this program will print name and score and grade of each student for every subject.", "md__r_e_a_d_m_e.html#autotoc_md15", null ]
        ] ],
        [ "Output -", "md__r_e_a_d_m_e.html#autotoc_md16", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_c_make_c_compiler_id_8c.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
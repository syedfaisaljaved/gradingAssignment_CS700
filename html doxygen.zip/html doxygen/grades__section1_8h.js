var grades__section1_8h =
[
    [ "Student", "struct_student.html", "struct_student" ],
    [ "calculateAverageAndGradesOfStudents", "grades__section1_8h.html#a8b14de9220bc01bf6c0cafcaf9ed110d", null ],
    [ "calculateGrade", "grades__section1_8h.html#ac1b888448d7612580f1e6ca9ae5e20c9", null ],
    [ "calculateMarksAverage", "grades__section1_8h.html#a5cd10be98b1e05af477794df6d026f11", null ],
    [ "extractDataAndWriteToFile", "grades__section1_8h.html#a090bb094ea0435358785485df6ceffcc", null ],
    [ "getFileInputName", "grades__section1_8h.html#a6034e049c19822b685da264f6c1af46e", null ],
    [ "getFileOutputName", "grades__section1_8h.html#ae0bc0f52671d1f6bd3222920dd1cfddd", null ],
    [ "insertHorizontalDivider", "grades__section1_8h.html#a955d20fc6feeac53fb1647f32f26435f", null ],
    [ "printDataOnConsole", "grades__section1_8h.html#a899fba67a0a6a58ba07ebff38c48390b", null ],
    [ "printHorizontalDivider", "grades__section1_8h.html#a24b443af08f6c10ffb778616ed5e02af", null ],
    [ "printTableHeaderToConsole", "grades__section1_8h.html#a4d578336e46c2c854ea6f01fb3546160", null ],
    [ "readContentFromFile", "grades__section1_8h.html#a1b89b581685bc9606c1a319fd73a5d23", null ],
    [ "writeDataToFile", "grades__section1_8h.html#a1a3d5738d5bdd8e6c72efc65c3aff64b", null ],
    [ "writeTableHeaderToFile", "grades__section1_8h.html#a6f4f6c5e5458cc17d512da05dbfa6edd", null ]
];
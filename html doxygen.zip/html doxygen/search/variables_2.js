var searchData=
[
  ['grade_0',['grade',['../struct_student.html#aa2ee2d5c0a92bf663b2645e1ea0d877c',1,'Student']]],
  ['gradeforeachexamarr_1',['gradeForEachExamArr',['../struct_student_data_collection.html#a8fc2b810fbe6099d2e2a964586bb8a2d',1,'StudentDataCollection']]]
];

var searchData=
[
  ['inserthorizontaldivider_0',['insertHorizontalDivider',['../grades__section1_8cpp.html#af80143f9c5fb99ff7ba3c9ddc6103566',1,'insertHorizontalDivider(ofstream &amp;outputStream):&#160;grades_section1.cpp'],['../grades__section1_8h.html#a955d20fc6feeac53fb1647f32f26435f',1,'insertHorizontalDivider(std::ofstream &amp;):&#160;grades_section1.h']]],
  ['inserthorizontaldividerline_1',['insertHorizontalDividerLine',['../grades__section2_8cpp.html#a665fad91631757dded8df73535df63c8',1,'insertHorizontalDividerLine(ofstream &amp;outputStream):&#160;grades_section2.cpp'],['../grades__section2_8h.html#a35a38dbc0ab8ea268218748e43a851d0',1,'insertHorizontalDividerLine(std::ofstream &amp;):&#160;grades_section2.h']]]
];

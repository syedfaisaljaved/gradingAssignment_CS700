var searchData=
[
  ['eachexamscoresarr_0',['eachExamScoresArr',['../struct_student_data_collection.html#a5bed20f0333d25b74784f38f2b0e0f8b',1,'StudentDataCollection']]]
];

var searchData=
[
  ['architecture_5fid_0',['ARCHITECTURE_ID',['../_c_make_c_compiler_id_8c.html#aba35d0d200deaeb06aee95ca297acb28',1,'ARCHITECTURE_ID():&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#aba35d0d200deaeb06aee95ca297acb28',1,'ARCHITECTURE_ID():&#160;CMakeCXXCompilerId.cpp']]],
  ['averageofsubjectmarks_1',['averageOfSubjectMarks',['../struct_student.html#a66f8e4642915651b099adc74f2461a4e',1,'Student']]],
  ['averagescoreforeachexamarr_2',['averageScoreForEachExamArr',['../struct_student_data_collection.html#abd82b5a7b487616c4e2e33307aa0b1d5',1,'StudentDataCollection']]]
];

var searchData=
[
  ['student_0',['Student',['../struct_student.html',1,'']]],
  ['studentdatacollection_1',['StudentDataCollection',['../struct_student_data_collection.html',1,'']]]
];

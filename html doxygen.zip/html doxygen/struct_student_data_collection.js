var struct_student_data_collection =
[
    [ "averageScoreForEachExamArr", "struct_student_data_collection.html#abd82b5a7b487616c4e2e33307aa0b1d5", null ],
    [ "eachExamScoresArr", "struct_student_data_collection.html#a5bed20f0333d25b74784f38f2b0e0f8b", null ],
    [ "gradeForEachExamArr", "struct_student_data_collection.html#a8fc2b810fbe6099d2e2a964586bb8a2d", null ],
    [ "numberOfStudents", "struct_student_data_collection.html#aa6bd83cc7c901365dba034bc175ce2ce", null ],
    [ "numberOfSubjects", "struct_student_data_collection.html#a82b4f32f9a6e47478f58e7af314703ac", null ],
    [ "studentNamesArr", "struct_student_data_collection.html#a17d56587fa326552775cf889c72d8138", null ]
];
var searchData=
[
  ['readcontentfromfile_0',['readContentFromFile',['../grades__section1_8cpp.html#a84ebe3d7b6d67ed39ce4f13ce2a93600',1,'readContentFromFile(vector&lt; string &gt; &amp;fileContent):&#160;grades_section1.cpp'],['../grades__section1_8h.html#a1b89b581685bc9606c1a319fd73a5d23',1,'readContentFromFile(std::vector&lt; std::string &gt; &amp;):&#160;grades_section1.h']]],
  ['readfirstlinefromfile_1',['readFirstLineFromFile',['../grades__section2_8cpp.html#acd61f7d4e76ec448d36c2dda12da4241',1,'readFirstLineFromFile(StudentDataCollection &amp;student):&#160;grades_section2.cpp'],['../grades__section2_8h.html#a6ad0a630cb24b7cde0b263af842d7ab1',1,'readFirstLineFromFile(StudentDataCollection &amp;):&#160;grades_section2.cpp']]],
  ['readme_20doxygen_2emd_2',['README doxygen.md',['../_r_e_a_d_m_e_01doxygen_8md.html',1,'']]],
  ['readnameandscoresfromfile_3',['readNameAndScoresFromFile',['../grades__section2_8cpp.html#a5a6fe22c2a74dfe08f053aec7a4acd72',1,'readNameAndScoresFromFile(StudentDataCollection &amp;student):&#160;grades_section2.cpp'],['../grades__section2_8h.html#ab2fb8757dc360fa445e7db3207e99d0a',1,'readNameAndScoresFromFile(StudentDataCollection &amp;):&#160;grades_section2.cpp']]]
];

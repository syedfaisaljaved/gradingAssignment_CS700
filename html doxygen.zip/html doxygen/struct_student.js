var struct_student =
[
    [ "averageOfSubjectMarks", "struct_student.html#a66f8e4642915651b099adc74f2461a4e", null ],
    [ "grade", "struct_student.html#aa2ee2d5c0a92bf663b2645e1ea0d877c", null ],
    [ "name", "struct_student.html#a9aeb48a925f370292564def17482f0ec", null ],
    [ "numberOfSubjects", "struct_student.html#a1227d23a1259334fc3bb8b93e81ada13", null ]
];
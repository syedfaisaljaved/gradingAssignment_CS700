var grades__section2_8cpp =
[
    [ "calculateAverageScoreForEachSubject", "grades__section2_8cpp.html#a818cffa9d6f4eb13a34ae185ab7ccbcb", null ],
    [ "calculateGradeForEachExamScore", "grades__section2_8cpp.html#a1d72dcc763cfe17a9ad06b7973a96694", null ],
    [ "getSecondFileInputName", "grades__section2_8cpp.html#aa6909e61ebfe390af881bdd564490e9f", null ],
    [ "getSecondFileOutputName", "grades__section2_8cpp.html#ad6431f11086a9bb178551c131f145be2", null ],
    [ "insertHorizontalDividerLine", "grades__section2_8cpp.html#a665fad91631757dded8df73535df63c8", null ],
    [ "readFirstLineFromFile", "grades__section2_8cpp.html#acd61f7d4e76ec448d36c2dda12da4241", null ],
    [ "readNameAndScoresFromFile", "grades__section2_8cpp.html#a5a6fe22c2a74dfe08f053aec7a4acd72", null ],
    [ "writeStudentTableToFile", "grades__section2_8cpp.html#af480f1e7063335ec3c2c53354dad893a", null ],
    [ "writeTableHeaderToSecondFile", "grades__section2_8cpp.html#a8427b8cdb4e8e654dbafefd5ef440a0a", null ]
];
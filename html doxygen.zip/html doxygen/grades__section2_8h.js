var grades__section2_8h =
[
    [ "StudentDataCollection", "struct_student_data_collection.html", "struct_student_data_collection" ],
    [ "calculateAverageScoreForEachSubject", "grades__section2_8h.html#aca868df6705bc6911fd1f516f0325406", null ],
    [ "calculateGradeForEachExamScore", "grades__section2_8h.html#a84303b175445e31238a6f47ccf50696f", null ],
    [ "getSecondFileInputName", "grades__section2_8h.html#adf205cef988d47c817b81aa9078888c0", null ],
    [ "getSecondFileOutputName", "grades__section2_8h.html#a7dc01af72c244d230c59d09d78450bc8", null ],
    [ "insertHorizontalDividerLine", "grades__section2_8h.html#a35a38dbc0ab8ea268218748e43a851d0", null ],
    [ "readFirstLineFromFile", "grades__section2_8h.html#a6ad0a630cb24b7cde0b263af842d7ab1", null ],
    [ "readNameAndScoresFromFile", "grades__section2_8h.html#ab2fb8757dc360fa445e7db3207e99d0a", null ],
    [ "writeStudentTableToFile", "grades__section2_8h.html#a2fc1fdf37925137ebf588379b5518860", null ],
    [ "writeTableHeaderToSecondFile", "grades__section2_8h.html#ab3ec0531d6bf6a40a3e4c48c3da8c81b", null ]
];
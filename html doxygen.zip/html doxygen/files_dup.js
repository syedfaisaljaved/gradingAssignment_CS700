var files_dup =
[
    [ "cmake-build-debug", "dir_95e29a8b8ee7c54052c171a88bb95675.html", "dir_95e29a8b8ee7c54052c171a88bb95675" ],
    [ "grades_section1.cpp", "grades__section1_8cpp.html", "grades__section1_8cpp" ],
    [ "grades_section1.h", "grades__section1_8h.html", "grades__section1_8h" ],
    [ "grades_section2.cpp", "grades__section2_8cpp.html", "grades__section2_8cpp" ],
    [ "grades_section2.h", "grades__section2_8h.html", "grades__section2_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];
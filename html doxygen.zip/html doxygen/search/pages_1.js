var searchData=
[
  ['grades_5fsection2_2ecpp_0',['grades_section2.cpp',['../simple.html',1,'']]]
];

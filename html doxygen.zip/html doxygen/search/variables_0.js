var searchData=
[
  ['averageofsubjectmarks_0',['averageOfSubjectMarks',['../struct_student.html#a66f8e4642915651b099adc74f2461a4e',1,'Student']]],
  ['averagescoreforeachexamarr_1',['averageScoreForEachExamArr',['../struct_student_data_collection.html#abd82b5a7b487616c4e2e33307aa0b1d5',1,'StudentDataCollection']]]
];

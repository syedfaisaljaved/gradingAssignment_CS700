var annotated_dup =
[
    [ "Student", "struct_student.html", "struct_student" ],
    [ "StudentDataCollection", "struct_student_data_collection.html", "struct_student_data_collection" ]
];
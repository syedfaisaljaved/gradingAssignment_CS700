var searchData=
[
  ['name_0',['name',['../struct_student.html#a9aeb48a925f370292564def17482f0ec',1,'Student']]],
  ['numberofstudents_1',['numberOfStudents',['../struct_student_data_collection.html#aa6bd83cc7c901365dba034bc175ce2ce',1,'StudentDataCollection']]],
  ['numberofsubjects_2',['numberOfSubjects',['../struct_student.html#a1227d23a1259334fc3bb8b93e81ada13',1,'Student::numberOfSubjects()'],['../struct_student_data_collection.html#a82b4f32f9a6e47478f58e7af314703ac',1,'StudentDataCollection::numberOfSubjects()']]]
];
